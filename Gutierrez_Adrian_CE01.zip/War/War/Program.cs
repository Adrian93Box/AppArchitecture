﻿// Adrian Gutierrez
// 10/01/2020
// APA
// 1.2 Code Exercise

using System;
using System.Collections.Generic;

namespace War
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate the war application
            WarApp warApp = new WarApp();
        }
    }
}
